<div class="footer">
    <div class="pull-right">
        <strong>Developed by Aridian Technologies</strong>
    </div>
    <div>
        <strong>Copyright</strong> Unlimited Embroidery App &copy; 2019-2020
    </div>
</div>