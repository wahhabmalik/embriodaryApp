<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Thread extends Model
{
    protected $primaryKey = 'thread_id';
    protected $fillable = [
     	'name',
     	'color',
     ];
}
