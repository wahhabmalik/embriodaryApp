<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    // public function index()
    // {
    //     $users = User::all();
    //     return view('dashboard.users.list')->with('users',$users);
    // }

    // public function create()
    // {
    //     return view('dashboard.plans.form');
    // }
}
