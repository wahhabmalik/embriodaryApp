<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Cleaning;
use Faker\Generator as Faker;

$factory->define(Cleaning::class, function (Faker $faker) {
    return [
        //
    ];
});
